# Techfest-Micromouse
This repository contains the package **pkg_tf_micromouse**.

submitted by: Team : MC-213436

Uploaded video of submission : [here](https://www.youtube.com/watch?v=is9BNbxqwGE)

instructions for running simulation


0. Ensure that ```rospy``` and ```numpy``` are installed
1. paste **techfest-micromouse** folder in your local workspace's **src** directory.
2. make the scripts executable by running ```chmod +x vex.py walker.py scout.py``` from the **scripts** directory.
3. Build workspace with ```catkin_make```
4. Source workspace setup file present in devel directory.
5. Run ```roslaunch pkg_tf_micromouse final.launch```
