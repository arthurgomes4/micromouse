# Example Codes

<br/>

> **Note**: Here we have some python scripts to make you familiar with micromouse movement and laser scan. At the end of these tutorials, you'll be able to move micromouse in a maze with obstacle avoidance.

> **TODO**: Add demonstration videos as output in each tutorial.

---