#! /usr/bin/env python

# this node will read from /mm_robot/planar_twist 
# and write to /mm_robot/cmd_vel_x and /mm_robot/cmd_vel_y

import rospy
from geometry_msgs.msg import Twist

def main(x_vel_topic,y_vel_topic):
    rospy.init_node('bot_controller')
    