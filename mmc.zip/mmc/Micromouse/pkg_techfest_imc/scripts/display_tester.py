import cv2
import numpy as np


def display_points(points):

    size = 200
    T_ac = np.array([[1, 0,size/2],
                     [0,-1,size/2],
                     [0, 0,     1]])
    
    blank = np.zeros((size+1,size+1,3), dtype=np.uint8)
    Imin = -30
    Imax = 30
    Omin = -size/2
    Omax = size/2
    slope = (Omax - Omin)/(Imax - Imin)
    points[0:2][:] = (Omin + slope*(points[0:2][:] - Imin))

    pixels = np.matmul(T_ac,points)
    pixels = pixels.astype(int)
    
    for i in range(pixels.shape[1]):
        blank[pixels[1,i], pixels[0,i]] = (0,255,0)
        
    cv2.imshow('maze', blank)
    cv2.waitKey(0)
    return

pts = [[10, 10, 20, -30, -20, 30, 0],
       [20,10,-10, 10, -20, -30, 0  ],
       [1,  1,  1,   1,  1, 1, 1  ]]
points = np.array(pts)
display_points(points)