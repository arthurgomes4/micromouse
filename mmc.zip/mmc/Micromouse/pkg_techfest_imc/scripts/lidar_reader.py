#! /usr/bin/env python

import cv2
from numpy.core.numeric import Inf
import rospy
import numpy as np
from sensor_msgs.msg import LaserScan
n = 720
maxr = 3
def laser_callback(msg):
    data = np.zeros((1000,n), dtype=np.uint8)
    dists = np.array(msg.ranges)/maxr*1000
    for i in range(720):
        if dists[i] == Inf:
            dists[i] = 1000
        data[int(dists[i]-1)][i] = 255

    cv2.imshow('lidar',data)
    cv2.waitKey(1)




def main(laser_topic):
    rospy.init_node('laser_reader')
    rospy.Subscriber(laser_topic,LaserScan,laser_callback)
    rospy.spin()

if __name__ == '__main__':
    main("/laser/scan")