import numpy as np

def mat2point(i,j):

    divisor = 10
    corridor_width = 20
    wall_width = 0
    cells = 4

    disp = (divisor + cells*(corridor_width + wall_width))/2

    T_oc = np.array([[1, 0, -disp],
                     [0,-1, disp ],
                     [0, 0, 1    ]])

    c_point = np.array([[i*divisor + divisor/2],[j*divisor + divisor/2],[1]])
    # print(c_point)
    points = np.matmul(T_oc, c_point)

    print(points)

mat2point(1,1)
mat2point(6,1)