#! /usr/bin/env python

from numpy.core.numeric import Inf
import rospy
import numpy as np
from sensor_msgs.msg import LaserScan, PointCloud2
import sensor_msgs.point_cloud2 as pc2
import laser_geometry.laser_geometry as lg
import ros_numpy
import numpy as np
import cv2
import tf
from tf.transformations import euler_from_quaternion

def main():
    rospy.init_node('yooo')
    i =0 
    while not rospy.is_shutdown():
        print('run 1.'+str(i))
        if i == 10000000:
            break
        else: 
            i += 1

    while not rospy.is_shutdown():
        print('run 2')

    print('shutting down')

if __name__ == '__main__':
    main()

'''
[(16, 16), (16, 15), (15, 15), (15, 14), (15, 13), (14, 13), (13, 13), (12, 13), (11, 13), (11, 12), (11, 11), (12, 11), (13, 11), (13, 10), (13, 9), (14, 9), (15, 9), (16, 9), (17, 9), (17, 8), (17, 7), (17, 6), (17, 5), (16, 5), (15, 5), (14, 5), (13, 5), (13, 4), (13, 3), (14, 3), (15, 3), (16, 3), (17, 3), (18, 3), (19, 3), (20, 3), (21, 3), (22, 3), (23, 3), (24, 3), (25, 3), (25, 4), (25, 5), (25, 6), (25, 7), (25, 8), (25, 9), (25, 10), (25, 11), (25, 12), (25, 13), (24, 13), (23, 13), (22, 13), (21, 13), (20, 13), (19, 13), (19, 14), (19, 15), (20, 15), (21, 15), (22, 15), (23, 15), (24, 15), (25, 15), (26, 15), (27, 15), (28, 15), (29, 15), (30, 15), (31, 15), (31, 14), (31, 13), (31, 12), (31, 11), (31, 10), (31, 9), (31, 8), (31, 7), (31, 6), (31, 5), (31, 4), (31, 3), (31, 2), (31, 1), (30, 1), (29, 1), (28, 1), (27, 1), (26, 1), (25, 1), (24, 1), (23, 1), (22, 1), (21, 1), (20, 1), (19, 1), (18, 1), (17, 1), (16, 1), (15, 1), (14, 1), (13, 1), (12, 1), (11, 1), (10, 1), (9, 1), (8, 1), (7, 1), (6, 1), (5, 1), (4, 1), (3, 1), (2, 1)]

'''
