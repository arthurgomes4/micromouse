#! /usr/bin/env python

from numpy.core.numeric import Inf
import rospy
import numpy as np
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
import cv2
import tf
from tf.transformations import euler_from_quaternion
import heapq as hp
import math as m
from pkg_techfest_imc.srv import move, moveRequest, moveTrajRequest, moveTraj

class maze_mapper:

    def __init__(self, laser_topic, pos_topic):

        # load maze paraeters
        wall_width = 0.012
        cell_number = 16
        corridor_width = 0.168

        # create blank for visualization
        size = 600
        self.blank = np.zeros((size+1,size+1,3), dtype=np.uint8)
        # divisor for cell identification
        self.divisor = (wall_width + corridor_width)/2

        # transfrom from {c} to {o}
        disp = (self.divisor + cell_number*(corridor_width + wall_width))/2
        self.T_co = np.array([[ 1,  0, disp],
                              [ 0, -1, disp],
                              [ 0,  0,    1]])

        # create occupancy matrix
        self.occ_mat = np.ones((cell_number*2+1,cell_number*2+1), dtype=np.int_)
        self.occ_matrix_update = 0
        self.occ_mat[0:cell_number*2+1,0] = 0
        self.occ_mat[0,0:cell_number*2+1] = 0
        self.occ_mat[0:cell_number*2+1,cell_number*2] = 0
        self.occ_mat[cell_number*2,0:cell_number*2+1] = 0

        # initialize node
        rospy.init_node('maze_mapper_v1')
        rospy.Subscriber(laser_topic,LaserScan,self.laser_callback)
        self.tf_lis = tf.TransformListener()
        self.service_container = rospy.ServiceProxy('move_to_goal', move)
        self.service_container_2 = rospy.ServiceProxy('move_traj', moveTraj)
        self.mapper_rate = rospy.Rate(10)
        rospy.loginfo('node setup complete')
        
        path = [(16, 16), (16, 15), (15, 15), (15, 14), (15, 13), 
        (14, 13), (13, 13), (12, 13), (11, 13), (11, 12), 
        (11, 11), (12, 11), (13, 11), (13, 10), (13, 9), 
        (14, 9), (15, 9), (16, 9), (17, 9), (17, 8), 
        (17, 7), (17, 6), (17, 5), (16, 5), (15, 5), 
        (14, 5), (13, 5), (13, 4), (13, 3), (14, 3), 
        (15, 3), (16, 3), (17, 3), (18, 3), (19, 3), 
        (20, 3), (21, 3), (22, 3), (23, 3), (24, 3), 
        (25, 3), (25, 4), (25, 5), (25, 6), (25, 7), 
        (25, 8), (25, 9), (25, 10), (25, 11), (25, 12), 
        (25, 13), (24, 13), (23, 13), (22, 13), (21, 13), 
        (20, 13), (19, 13), (19, 14), (19, 15), (20, 15), 
        (21, 15), (22, 15), (23, 15), (24, 15), (25, 15), 
        (26, 15), (27, 15), (28, 15), (29, 15), (30, 15), 
        (31, 15), (31, 14), (31, 13), (31, 12), (31, 11), 
        (31, 10), (31, 9), (31, 8), (31, 7), (31, 6), 
        (31, 5), (31, 4), (31, 3), (31, 2), (31, 1), 
        (30, 1), (29, 1), (28, 1), (27, 1), (26, 1), 
        (25, 1), (24, 1), (23, 1), (22, 1), (21, 1), 
        (20, 1), (19, 1), (18, 1), (17, 1), (16, 1), 
        (15, 1), (14, 1), (13, 1), (12, 1), (11, 1), 
        (10, 1), (9, 1), (8, 1), (7, 1), (6, 1), 
        (5, 1), (4, 1), (3, 1), (2, 1)]

        path = path[::-1]
        #====================================================================
        # # figure out where bot is 
        # bot_pos = self.locate_bot(pos_topic)
        # print(type(bot_pos))
        # while not self.occ_matrix_update:
        #     pass
        # # start initial conditions
        # maze = np.copy(self.occ_mat)
        # path = self.find_path(maze, bot_pos, (16,16))
        # node,path = self.find_dir_change(path)
        # ret = self.request_move(node[0],node[1])

        # # loop here
        # while not rospy.is_shutdown():
            
        #     #update the maze
        #     maze = np.copy(self.occ_mat)

        #     # check path
        #     if self.check_path(maze, path):
        #         path = self.find_path(maze, node, (16,16))
            
        #     if len(path) == 0:
        #         break
        #     # find dir change
        #     node,path = self.find_dir_change(path)

        #     # go to dir change
        #     ret = self.request_move(node[0],node[1])

        # # start initial conditions
        # maze = np.copy(self.occ_mat)
        # path = self.find_path(maze, (16,16), bot_pos)
        # print(path)
        # node,path = self.find_dir_change(path)
        # ret = self.request_move(node[0],node[1])

        # while not rospy.is_shutdown():
            
        #     #update the maze
        #     maze = np.copy(self.occ_mat)

        #     # check path
        #     if self.check_path(maze, path):
        #         path = self.find_path(maze, node, bot_pos)
            
        #     if len(path) == 0:
        #         break
        #     # find dir change
        #     node,path = self.find_dir_change(path)

        #     # go to dir change
        #     ret = self.request_move(node[0],node[1])

        # # start initial conditions
        # maze = np.copy(self.occ_mat)
        # path = self.find_path(maze, (bot_pos), (16,16))

        # while not rospy.is_shutdown():
        #     if len(path) == 0:
        #         break
        #     node,path = self.find_dir_change(path)
        #     ret = self.request_move(node[0],node[1])
        #=======================================================================
        self.request_traj(path)

        print('shuting down')

    def locate_bot(self, pos_topic):
        odom_msg = rospy.wait_for_message(pos_topic, Odometry)
        o_point = [[odom_msg.pose.pose.position.x], [odom_msg.pose.pose.position.y],[1]]
        c_point = np.matmul(self.T_co, o_point)
        element = c_point//self.divisor
        return (int(element[1]), int(element[0]))

    def request_move(self,i,j):
        rospy.wait_for_service('move_to_goal')
        try:
            req = moveRequest()
            req.i = i
            req.j = j
            resp = self.service_container(req)
            return resp.ack
        except rospy.ServiceException as e:
            print("Service call failed: %s"%e)

    def request_traj(self,path):
        rospy.wait_for_service('move_traj')
        try:
            req = moveTrajRequest()
            for node in path:
                req.i.append(node[0])
                req.j.append(node[1])
            resp = self.service_container_2(req)
            return resp.ack
        except rospy.ServiceException as e:
            print("Service call failed: %s"%e)

    def find_dir_change(self,path):
        dir = (path[1][0] - path[0][0], path[1][1] - path[0][1])

        for i in range(1,len(path)-1):
            if (path[i+1][0] - path[i][0], path[i+1][1] - path[i][1]) != dir:
                return path[i], path[i:]

        return path[-1], []

    def check_path(self, maze, path):
        # path is a list of tuples
        for node in path:
            if not maze[node[0],node[1]]:
                return 1
        return 0

    def find_path(self, maze, start, goal):
        maze_dims = (maze.shape[0], maze.shape[1])

        open_nodes = []
        closed_nodes = np.zeros(maze_dims, dtype=np.bool)
        past_cost_matrix = np.full(maze_dims, np.Inf)
        parent_matrix = np.full((maze_dims[0],maze_dims[1],2), None)

        # initializing OPEN with start
        # heuristic added cost, node_pos
        hp.heappush(open_nodes, (0,start))
        past_cost_matrix[start[0], start[1]] = 0

        while len(open_nodes) > 0:

            current = hp.heappop(open_nodes)[1]
            closed_nodes[current[0], current[1]] = True

            if current == goal:
                path = []
                print('reached')
                while current != (None,None):
                    path.append(current)
                    current = (parent_matrix[current[0], current[1], 0], parent_matrix[current[0], current[1], 1])

                # to display path ============
                for node in path:
                    maze[node[0],node[1]] = 2
                for row in maze:
                    print(row)
                # ============================

                
                return path[::-1]

            # find neighbours of CURRENT
            # create a neighbours list of each row having current_ctg, node_pos

            directions = ((-1,  0), # north
                        ( 0, -1), # west
                        ( 1,  0), # south
                        ( 0,  1)) # east

            for dir in directions:
                neighbour = (current[0] + dir[0], current[1] + dir[1])
                if closed_nodes[neighbour[0], neighbour[1]] or not maze[neighbour[0], neighbour[1]]:
                    continue
                else:
                    # temp = past cost of CURRENT + Heuristic of neighbour + 1 (step size)
                    temp = past_cost_matrix[current[0], current[1]] + 1
                    
                    if temp < past_cost_matrix[neighbour[0], neighbour[1]]:

                        past_cost_matrix[neighbour[0], neighbour[1]] = temp
                        parent_matrix[neighbour[0], neighbour[1]] = current

                        # we have to change the past cost in OPEN as well
                        k=0
                        for i in range(len(open_nodes)):
                            if open_nodes[i][1] == neighbour:
                                open_nodes[i][1] = temp + m.sqrt((goal[0]-neighbour[0])**2 + (goal[1]-neighbour[1])**2)
                                hp.heapify(open_nodes)
                                k = 1
                                break
                        if not k:        
                            hp.heappush(open_nodes, (temp + m.sqrt((goal[0]-neighbour[0])**2 + (goal[1]-neighbour[1])**2), neighbour))

    def lasermsg_2_xy(self, msg):
        distances = np.array(msg.ranges)
        theta = np.arange(msg.angle_min, msg.angle_max + msg.angle_increment*0.5, msg.angle_increment)
        X = distances*np.cos(theta)
        Y = distances*np.sin(theta)
        l_points = np.stack((X,Y,np.ones((len(X)))))
        return l_points

    def laser_callback(self, laser_msg):

        # calculate points in lidar frame
        l_points = self.lasermsg_2_xy(laser_msg)

        # calculate points in corner frame
        try:
            t = self.tf_lis.lookupTransform('/odom', '/micromouse_frame', rospy.Time(0))
            (x,y) = t[0][0:2]
            (roll, pitch, yaw) = euler_from_quaternion(t[1])
            yaw *= -1
            T_ol = np.array([[np.cos(yaw), np.sin(yaw), x],[-np.sin(yaw), np.cos(yaw), y],[0,0,1]])
            T_cl = np.matmul(self.T_co, T_ol)

            # only for display ===================
            # v_points = np.matmul(T_ol, l_points)
            # self.display_points(v_points)
            # ====================================

            c_points = np.matmul(T_cl, l_points)
            c_points = c_points//self.divisor
            elements = c_points[0:2, :]

            for point in np.transpose(elements):
                self.occ_mat[int(point[1]),int(point[0])] = 0

            self.occ_matrix_update = 1

        except tf.LookupException:
            pass

    def display_points(self,points):

        size = 600
        blank = np.zeros((size+1,size+1,3), dtype=np.uint8)
        # blank = np.zeros((size+1,size+1,3), dtype=np.uint8)
        T_ac = np.array([[1, 0,size/2],
                        [0,-1,size/2],
                        [0, 0,     1]])
        
        Imin = -3
        Imax = 3
        Omin = -size/2
        Omax = size/2
        slope = (Omax - Omin)/(Imax - Imin)
        points[0:2][:] = (Omin + slope*(points[0:2][:] - Imin))

        pixels = np.matmul(T_ac,points)
        pixels = pixels.astype(int)
        
        for i in range(pixels.shape[1]):
            blank[pixels[1,i], pixels[0,i]] = (0,255,0)
            
        cv2.imshow('maze', blank)
        cv2.waitKey(1)
        return

if __name__ == '__main__':
    o = maze_mapper('/laser/scan','/odom')