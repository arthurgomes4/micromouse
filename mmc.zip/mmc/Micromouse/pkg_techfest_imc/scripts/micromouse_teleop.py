#! /usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from rospy.core import loginfo

def teleop_callback(msg):
    scaler = 0.1
    x_msg = Twist()
    x_msg.linear.x = msg.linear.x*scaler
    x_msg.angular.z = msg.angular.z
    y_msg = Twist()
    y_msg.linear.x = msg.linear.y*scaler
    y_msg.angular.z = msg.angular.z
    x_vel_pub.publish(x_msg)
    y_vel_pub.publish(y_msg)

def main(x_vel_topic,y_vel_topic,teleop_topic):
    rospy.init_node('micromouse_teleop')
    teleop_sub = rospy.Subscriber(teleop_topic, Twist, teleop_callback)
    global x_vel_pub, y_vel_pub
    x_vel_pub = rospy.Publisher(x_vel_topic,Twist,queue_size=1)
    y_vel_pub = rospy.Publisher(y_vel_topic,Twist,queue_size=1)
    rospy,loginfo('waiting for /cmd_vel..')
    rospy.spin()

if __name__ == '__main__':
    main("/cmd_vel_x","/cmd_vel_y","/cmd_vel")

