import heapq as hp
import numpy as np
import math as m

maze_dims = (13,13)
# maze = np.ones(maze_dims, dtype=bool)

# testing
maze = np.array(   [[0, 0,0,0,0, 0,0,0, 0,0,0,0, 0],

                    [0, 1,0,1,1, 1,1,1, 0,1,0,1, 0],
                    [0, 1,0,1,0, 0,0,0, 0,1,0,1, 0],
                    [0, 1,1,1,0, 1,1,1, 1,1,0,1, 0],
                    [0, 1,0,0,0, 0,0,1, 0,1,0,1, 0],

                    [0, 1,0,1,0, 1,1,1, 0,1,0,1, 0],
                    [0, 1,0,1,0, 1,1,1, 0,1,0,1, 0],
                    [0, 1,1,1,0, 1,1,1, 0,1,1,1, 0],

                    [0, 1,0,1,0, 0,0,0, 0,1,0,1, 0],
                    [0, 1,0,1,1, 1,1,1, 1,1,0,1, 0],
                    [0, 1,0,0,0, 1,0,0, 0,1,0,0, 0],
                    [0, 1,0,1,1, 1,1,1, 0,1,1,1, 0],

                    [0, 0,0,0,0, 0,0,0, 0,0,0,0, 0]] )

open_nodes = []
closed_nodes = np.zeros(maze_dims, dtype=np.bool)
past_cost_matrix = np.full(maze_dims, np.Inf)
parent_matrix = np.full((maze_dims[0],maze_dims[1],2), None)

start = (1,1)
goal = (6,6)

# initializing OPEN with start
# heuristic added cost, node_pos
hp.heappush(open_nodes, (0,start))
past_cost_matrix[start[0], start[1]] = 0

while len(open_nodes) > 0:

    current = hp.heappop(open_nodes)[1]
    closed_nodes[current[0], current[1]] = True

    if current == goal:
        path = []
        print('reached')
        while current != (None,None):
            path.append(current)
            current = (parent_matrix[current[0], current[1], 0], parent_matrix[current[0], current[1], 1])
    
        for node in path:
            maze[node[0],node[1]] = 2
        print(maze)
        exit(0)

    # find neighbours of CURRENT
    # create a neighbours list of each row having current_ctg, node_pos

    directions = ((-1,  0), # north
                  ( 0, -1), # west
                  ( 1,  0), # south
                  ( 0,  1)) # east

    for dir in directions:
        neighbour = (current[0] + dir[0], current[1] + dir[1])
        if closed_nodes[neighbour[0], neighbour[1]] or not maze[neighbour[0], neighbour[1]]:
            continue
        else:
            # temp = past cost of CURRENT + Heuristic of neighbour + 1 (step size)
            temp = past_cost_matrix[current[0], current[1]] + 1
            
            if temp < past_cost_matrix[neighbour[0], neighbour[1]]:

                past_cost_matrix[neighbour[0], neighbour[1]] = temp
                parent_matrix[neighbour[0], neighbour[1]] = current

                # we have to change the past cost in OPEN as well
                k=0
                for i in range(len(open_nodes)):
                    if open_nodes[i][1] == neighbour:
                        open_nodes[i][1] = temp + m.sqrt((goal[0]-neighbour[0])**2 + (goal[1]-neighbour[1])**2)
                        hp.heapify(open_nodes)
                        k = 1
                        break
                if not k:        
                    hp.heappush(open_nodes, (temp + m.sqrt((goal[0]-neighbour[0])**2 + (goal[1]-neighbour[1])**2), neighbour))
